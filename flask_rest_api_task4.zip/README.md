# Flask REST API - Task 4

## Objective
Build a REST API using Flask to manage user data.

## Features
- GET all users
- GET user by ID
- POST new user
- PUT update user
- DELETE user

## Installation
```bash
pip install -r requirements.txt
python app.py
```

## Endpoints
- GET /users
- GET /users/<id>
- POST /users
- PUT /users/<id>
- DELETE /users/<id>
